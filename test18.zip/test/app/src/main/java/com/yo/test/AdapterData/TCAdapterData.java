package com.yo.test.AdapterData;

public class TCAdapterData {
    private String data;

    public TCAdapterData(String data) {
        this.data = data;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

}

