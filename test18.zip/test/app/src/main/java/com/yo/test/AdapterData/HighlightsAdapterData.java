package com.yo.test.AdapterData;

import android.graphics.Bitmap;

public class HighlightsAdapterData {
    private String data;

    public HighlightsAdapterData(String data) {
        this.data = data;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

}

