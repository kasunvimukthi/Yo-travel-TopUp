package com.yo.test;

public class Conn {

    public static String url = "jdbc:mysql://192.168.43.108:3306/traveldb";
    public static String user = "root";
    public static String pass = "";



}
