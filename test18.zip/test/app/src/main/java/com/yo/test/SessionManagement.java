//package com.yo.test;
//
//import android.content.Context;
//import android.content.SharedPreferences;
//
//public class SessionManagement {
//    SharedPreferences sharedPreferences;
//    SharedPreferences.Editor editor;
//    String User_Name_Session = "session";
//    String Session_Key = "session_user";
//
//    public SessionManagement(Context context){
//        sharedPreferences = context.getSharedPreferences(User_Name_Session,Context.MODE_PRIVATE);
//        editor = sharedPreferences.edit();
//    }
//
//    public void saveSession(User user){
//
//    }
//    public int getSession(){
//        return -1;
//    }
//}
